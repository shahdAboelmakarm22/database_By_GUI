package com.example.dbproj;
import java.time.LocalDate;

public class Book {
    private int bookID;
    private String title;
    private String category;
    private LocalDate publicationDate;
    private String authorName;

    public Book(int bookID, String title, String category, LocalDate publicationDate, String authorName) {
        this.bookID = bookID;
        this.title = title;
        this.category = category;
        this.publicationDate = publicationDate;
        this.authorName = authorName;
    }

    // Getters and setters (optional)
    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public LocalDate getPublicationDate() {
        return publicationDate;
    }

    public void setPublicationDate(LocalDate publicationDate) {
        this.publicationDate = publicationDate;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
    @Override
    public String toString() {
        return title;
    }
}
