package com.example.dbproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class LoginOptionsController extends Controller{

    @FXML
    private Button memberB;

    @FXML
    private Button staffB;

    @FXML
    void memberAction(ActionEvent event) {
        try {
            switchScene(event, "MemLogin.fxml", "MemLogin");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void staffAction(ActionEvent event) {
        try {
            switchScene(event, "StaffLogin.fxml", "Staff Login");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
