package com.example.dbproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.io.IOException;

public class MemOptionsController extends Controller{

    @FXML
    private Button browseBtn;

    @FXML
    private Button resBtn;

    @FXML
    private Label nameLbl;

    @FXML
    private Label statuslbl;

    @FXML
    private Button updateprofBtn;

    public void setup(){
        String userName = Jdbc.getUserName(userid);
        if (userName != null) {
            nameLbl.setText(userName);
        } else {
            nameLbl.setText("User not found");
        }
        boolean userStatus = Jdbc.getStatus(userid);
        if (userStatus ) {
            statuslbl.setText("Active");
        } else {
            statuslbl.setText("Inactive");
        }
    }

    @FXML
    void browseAction(ActionEvent event) {
        try {
            switchScene(event,"ViewBooks.fxml", "ViewBooks", userid);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @FXML
    void resAction(ActionEvent event) {
        try {
            switchScene(event,"ViewReservations.fxml", "ViewReservations", userid);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void updateprofAction(ActionEvent event) {
        try {
            switchScene(event,"UpdteOptions.fxml", "UpdateOptions", userid);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
