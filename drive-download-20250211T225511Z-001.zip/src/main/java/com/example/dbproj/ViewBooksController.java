package com.example.dbproj;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ViewBooksController extends Controller {

    @FXML
    private Label Author;

    @FXML
    private Button Back_Button;

    @FXML
    private ComboBox<Book> BooksComboBox; // Changed to use Book objects

    @FXML
    private Label Category;

    @FXML
    private Label Publication;

    @FXML
    private Label authorlbl;

    @FXML
    private Label bookId;

    @FXML
    private Label booklbl;

    @FXML
    private Label categorylbl;

    @FXML
    private Label publicationlbl;

    private Book selectedBook;

    public void initialize() {
        String query = "SELECT Book.Book_Id, Book.Title, Category.Category_Name, Book.Publication_Date, " +
                "Author.First_Name AS Author_First_Name, Author.Last_Name AS Author_Last_Name " +
                "FROM Book " +
                "JOIN Category ON Book.Category_Id = Category.Category_Id " +
                "JOIN Author_Book ON Book.Book_Id = Author_Book.Book_Id " +
                "JOIN Author ON Author.Author_Id = Author_Book.Author_Id";

        ArrayList<Book> books = Jdbc.GetBooks(query);
        ObservableList<Book> observableMovies = FXCollections.observableArrayList(books);
        BooksComboBox.setItems(observableMovies);
        BooksComboBox.setVisibleRowCount(10);
    }

    @FXML
    void BackButtonFun(ActionEvent event) {
        try{
            switchScene(event,"MemOptions.fxml", "Member Options",userid);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    @FXML
    void showBookDetails(ActionEvent event) {
        selectedBook = BooksComboBox.getSelectionModel().getSelectedItem();

        if (selectedBook != null) {
            // Formatting publication date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            String publicationDate = selectedBook.getPublicationDate().format(formatter);

            // Setting values to labels
            bookId.setText(Integer.toString(selectedBook.getBookID()));
            booklbl.setText(selectedBook.getTitle());
            categorylbl.setText(selectedBook.getCategory());
            authorlbl.setText(selectedBook.getAuthorName());
            publicationlbl.setText(publicationDate);

            // Making labels visible
            bookId.setVisible(true);
            booklbl.setVisible(true);
            categorylbl.setVisible(true);
            authorlbl.setVisible(true);
            publicationlbl.setVisible(true);

            // Making field labels visible
            Author.setVisible(true);
            Category.setVisible(true);
            Publication.setVisible(true);
        } else {
            System.out.println("Book not found");
        }
    }
}