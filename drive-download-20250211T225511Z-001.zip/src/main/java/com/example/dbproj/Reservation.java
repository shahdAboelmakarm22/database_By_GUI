package com.example.dbproj;

import java.sql.Date;

public class Reservation {
    private int resId;
    private int bookId;
    private String memberId;
    private Date reservationDate;
    private String resStatus;

    // Constructor
    public Reservation(int resId, int bookId, String memberId, Date reservationDate, String resStatus) {
        this.resId = resId;
        this.bookId = bookId;
        this.memberId = memberId;
        this.reservationDate = reservationDate;
        this.resStatus = resStatus;
    }

    // Getters and Setters
    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getResStatus() {
        return resStatus;
    }

    public void setResStatus(String resStatus) {
        this.resStatus = resStatus;
    }
}