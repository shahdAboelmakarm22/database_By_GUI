package com.example.dbproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class UpdteOptionsController extends Controller{

    @FXML
    private Button BackButton;

    @FXML
    private Button emailBtn;

    @FXML
    private Button passBtn;

    @FXML
    void BackFunc(ActionEvent event) {
        try{
            switchScene(event,"MemOptions.fxml", "Member Options",userid);
        }catch(IOException e){
            e.printStackTrace();
        }

    }
    @FXML
    void emailAction(ActionEvent event) {
        try {
            switchScene(event,"AddEmail.fxml", "AddEmail", userid);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void passAction(ActionEvent event) {
        try {
            switchScene(event,"UpdatePassword.fxml", "UpdatePassword", userid);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
