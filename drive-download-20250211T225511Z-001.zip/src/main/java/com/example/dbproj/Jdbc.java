package com.example.dbproj;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Jdbc {
    public static int validateLoginMEM (int id, String password,String query){
        int userid=-1;
       // String query="SELECT * FROM Member WHERE Member_id=? and Password=?";
        SQLConnection sqlConnector = SQLConnection.getInstance();
        try (Connection connection = sqlConnector.getConnection();) {
            if (connection == null) {
                System.out.println("Failed to establish a connection to the database.");
                return -1; // Early return if the connection fails
            }
            try (PreparedStatement statement = connection.prepareStatement(query);) {
                statement.setInt(1, id);
                statement.setString(2, password);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    userid=resultSet.getInt("Member_id");
                    return userid;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userid;
    }
    public static String getUserName(int userid) {

        SQLConnection sqlConnector = SQLConnection.getInstance();
        String userName = null;
        String query="SELECT first_name, Last_name FROM Member WHERE member_id = ?";
        try(Connection connection = sqlConnector.getConnection();){
            if (connection == null) {
                throw new SQLException("Failed to establish a connection to the database.");
            }
            try(PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, userid);

                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    userName=resultSet.getString("first_name") +" "+ resultSet.getString("Last_name");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userName;
    }

    public static boolean getStatus(int userid) {
        SQLConnection sqlConnector = SQLConnection.getInstance();
        boolean userStatus = false;
        String query="SELECT Active_status FROM member WHERE member_id = ?";
        try(Connection connection = sqlConnector.getConnection();){
            if (connection == null) {
                throw new SQLException("Failed to establish a connection to the database.");
            }
            try(PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, userid);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    userStatus=resultSet.getBoolean("Active_status");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userStatus;
    }

    public static boolean UpdateEmail(String email, int userid) {
        String query="Insert into M_email (Member_id, email) values (?,?)";
        SQLConnection sqlConnector = SQLConnection.getInstance();
        try (Connection connection = sqlConnector.getConnection();) {
            if (connection == null) {
                throw new SQLException("Failed to establish a connection to the database.");
            }
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, userid);
                statement.setString(2, email);

                int result = statement.executeUpdate();
                if (result > 0) {
                    return true;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();

        }
        return false;
    }

    public static boolean Updatepassword(String newp, String query, int userid) {
        SQLConnection sqlConnecter = SQLConnection.getInstance();
        try (Connection connection = sqlConnecter.getConnection()) {
            if (connection == null) {
                throw new SQLException("failed to establish connection");
            }
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, newp);
                preparedStatement.setInt(2, userid);

                int result = preparedStatement.executeUpdate();
                return result > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static String getOldPass(String query, int userid) {
        SQLConnection sqlConnector = SQLConnection.getInstance();
        String oldPass = null;
        try (Connection connection = sqlConnector.getConnection();) {
            if (connection == null) {
                throw new SQLException("Failed to establish a connection to the database.");
            }
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, userid);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    oldPass = resultSet.getString("Password");
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return oldPass;
    }

    public static ArrayList<Book> GetBooks(String query) {
        SQLConnection sqlConnector = SQLConnection.getInstance();
        ArrayList<Book> books = new ArrayList<>();
        try (Connection connection = sqlConnector.getConnection()) {
            if (connection == null) {
                throw new SQLException("Failed to establish a connection to the database.");
            }
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                ResultSet resultSet = statement.executeQuery();
                if (!resultSet.next()) {
                    System.out.println("No books found in the database.");
                }
                do {
                    int bookID = resultSet.getInt("Book_Id");
                    String title = resultSet.getString("Title");
                    System.out.println("Fetched book title: " + title);
                    String category = resultSet.getString("Category_Name");
                    LocalDate publicationDate = resultSet.getDate("Publication_Date").toLocalDate();
                    String authorFirstName = resultSet.getString("Author_First_Name");
                    String authorLastName = resultSet.getString("Author_Last_Name");
                    String authorName = authorFirstName + " " + authorLastName;

                    // Assuming Book class has been updated to include the author's name
                    Book book = new Book(bookID, title, category, publicationDate, authorName);
                    books.add(book);
                } while (resultSet.next());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    public static ObservableList<Reservation> getReservations(int memberId, String query) {
        ObservableList<Reservation> reservations = FXCollections.observableArrayList();
        SQLConnection sqlConnecter = SQLConnection.getInstance();
        try (Connection connection = sqlConnecter.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setInt(1, memberId);
            ResultSet rs = stmt.executeQuery();
            if (!rs.next()) {
                System.out.println("No reservations found for member ID: " + memberId);
            } else {
                do {
                    int resId = rs.getInt("Res_id");
                    int bookId = rs.getInt("Book_id");
                    String memberIdFromDB = rs.getString("Member_id");
                    Date reservationDate = rs.getDate("Reservation_Date");
                    String resStatus = rs.getString("Res_Status");
                    Reservation reservation = new Reservation(resId, bookId, memberIdFromDB, reservationDate, resStatus);
                    reservations.add(reservation);
                } while (rs.next());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reservations;
    }

    public static boolean cancelReservation(int resId) {
        SQLConnection sqlConnector = SQLConnection.getInstance();

        // Query to delete the reservation from the Reservation table
        String deleteReservationQuery = "DELETE FROM Reservation WHERE Res_id = ?";

        try (Connection connection = sqlConnector.getConnection()) {
            if (connection == null) {
                throw new SQLException("Failed to establish a connection to the database.");
            }
            connection.setAutoCommit(false);

            try (PreparedStatement statement = connection.prepareStatement(deleteReservationQuery)) {
                statement.setInt(1, resId);
                int deleteResult = statement.executeUpdate();

                // If no rows were deleted, rollback and return false
                if (deleteResult == 0) {
                    connection.rollback();
                    return false;
                }
            }

            // Commit the transaction if everything is successful
            connection.commit();
            return true;

        } catch (SQLException e) {
            // Rollback in case of an exception
            try (Connection connection = sqlConnector.getConnection()) {
                if (connection != null) {
                    connection.rollback();
                }
            } catch (SQLException rollbackEx) {
                e.printStackTrace();
            }
            e.printStackTrace();
            return false;
        }
    }




}
