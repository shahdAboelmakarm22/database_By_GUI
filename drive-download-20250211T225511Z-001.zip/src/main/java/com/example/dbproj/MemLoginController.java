package com.example.dbproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Window;

import java.io.IOException;

public class MemLoginController extends Controller {

    @FXML
    private TextField idTf;

    @FXML
    private Button loginbutton;

    @FXML
    private TextField passTf;

    @FXML
    void loginAction(ActionEvent event) {
        Window owner = loginbutton.getScene().getWindow();
        if(idTf.getText().isEmpty()){
            showAlert(Alert.AlertType.ERROR,owner,"Error!","Please enter your email!");
            return;
        }
        if(passTf.getText().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, owner, "Error!", "Please enter your password!");
            return;
        }
        int id= Integer.parseInt(idTf.getText());
        String password= passTf.getText();
        String query="SELECT * FROM Member WHERE Member_Id=? and Password=?";
        userid=Jdbc.validateLoginMEM(id, password,query);
        if(userid == -1){
            showAlert(Alert.AlertType.ERROR,owner,"Error!","Invalid username or password!");
            return;
        }else {
           try{
               //send userid
                switchScene(event,"MemOptions.fxml", "Member Options",userid);
            }catch(IOException e){
                e.printStackTrace();
            }
        }
    }

}
