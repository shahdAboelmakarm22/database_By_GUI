package com.example.dbproj;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.event.ActionEvent;
import javafx.stage.Window;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.time.ZoneId;

public class ViewReservationsController extends Controller {

    @FXML
    private TableColumn<Reservation, Integer> ReservationIdCol; // Changed to Integer
    @FXML
    private Button cancelButton;

    @FXML
    private TableView<Reservation> reservationTable;

    @FXML
    private TableColumn<Reservation, String> bookIdCol;

    @FXML
    private TableColumn<Reservation, String> memberIdCol;

    @FXML
    private TableColumn<Reservation, Date> reservationDateCol;

    @FXML
    private TableColumn<Reservation, String> resStatusCol;

    private ObservableList<Reservation> reservations;

    public void setup() {
        System.out.println("user id in setup" + userid);
        ReservationIdCol.setCellValueFactory(new PropertyValueFactory<>("resId")); // Matches the property name
        bookIdCol.setCellValueFactory(new PropertyValueFactory<>("bookId"));
        memberIdCol.setCellValueFactory(new PropertyValueFactory<>("memberId"));
        reservationDateCol.setCellValueFactory(new PropertyValueFactory<>("reservationDate"));
        resStatusCol.setCellValueFactory(new PropertyValueFactory<>("resStatus"));

        loadReservationData();
    }

    private void loadReservationData() {
        String query = "SELECT Res_id, Book_id, Member_id, Reservation_Date, Res_Status " +
                "FROM Reservation " +
                "WHERE Member_id = ?";

        reservations = Jdbc.getReservations(userid, query);

        if (reservations != null && !reservations.isEmpty()) {
            reservationTable.setItems(reservations);
        } else {
            System.out.println("No reservations to display for the member ID: " + userid);
        }
    }

    @FXML
    void backAction(ActionEvent event) {
        try {
            switchScene(event, "MemOptions.fxml", "Member Options", userid);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void cancelAction(ActionEvent event) {
        Window owner = cancelButton.getScene().getWindow();
        Reservation selectedR = reservationTable.getSelectionModel().getSelectedItem();
        if (selectedR != null) {
            ButtonType resultR = infoBox("Are you sure you want to cancel this reservation?", "Confirm Cancellation");
            int resId = selectedR.getResId(); // resId is now int
            java.sql.Date sqlDate = selectedR.getReservationDate();
            LocalDate reservationDate = sqlDate.toLocalDate();
            if (resultR == ButtonType.OK) {
                    boolean flag = Jdbc.cancelReservation(resId);
                    if (flag) {
                        infoBox("Your reservation has been successfully cancelled.", "Reservation Cancelled", "Reservation Cancelled.");
                        reservations.clear();
                        loadReservationData();
                    } else {
                        infoBox("Failed to cancel reservation.", "Error", "Cancellation Error.");
                    }

            }
        } else {
            showAlert(Alert.AlertType.ERROR, owner, "No Reservation selected", "Please select a reservation.");
            System.out.println("No row selected.");
        }
    }
}