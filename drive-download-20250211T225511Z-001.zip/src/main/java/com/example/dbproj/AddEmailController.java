package com.example.dbproj;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Window;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddEmailController extends Controller{

    @FXML
    private Button addBtn;
    @FXML
    private Button cancelBtn1;

    @FXML
    private TextField newemailTf;

    private String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
    private Pattern pattern = Pattern.compile(emailRegex);
    @FXML
    void addAction(ActionEvent event) {
            Window owner = addBtn.getScene().getWindow();
           String Newemail = newemailTf.getText();
                if (Newemail.isEmpty()){
                    showAlert(owner);
                } else {
                    Matcher match = pattern.matcher(Newemail);
                    if (!match.matches()) {
                        // If the email is not in a valid format, show an error
                        showAlert(Alert.AlertType.ERROR, owner, "UpdateEmail", "Please enter a valid email address.");
                    }else {
                        boolean flag = Jdbc.UpdateEmail(Newemail, userid);
                        try {
                            if (flag) {
                                infoBox("Your email address has been updated in our system.", "Email Updated Successfully", " Update Successful");
                                switchScene(event, "UpdteOptions.fxml", "UpdateOptions", userid);
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
        }
    @FXML
    void cancelAction(ActionEvent event) {
        try{
            switchScene(event,"MemOptions.fxml", "Member Options",userid);
        }catch(IOException e){
            e.printStackTrace();
        }

    }

}
