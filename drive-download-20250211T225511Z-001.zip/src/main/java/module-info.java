module com.example.dbproj {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.dbproj to javafx.fxml;
    exports com.example.dbproj;
}